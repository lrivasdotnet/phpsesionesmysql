<?php

function conectar()
{

    //Credenciales
    $usuario = "root";
    $password = "root";
    $servidor = "localhost";
    $base = "tarea03";

    try {
        $idConexion = mysqli_connect($servidor, $usuario, $password, $base);
    } catch (Exception $error) {
        $idConexion = null;
    }

    return $idConexion;
}

function desconectar($idConexion)
{
    mysqli_close($idConexion);
}


function iniciarSesion($usuario,$password){
    //Conectar
    $idConexion = conectar();
    $elpassword = md5($password);
    //Preparar un comando de tipo select
    $comando = "select * from usuarios WHERE usuario='$usuario' AND password='$elpassword' AND estado='1'";
    //Ejecutando la consulta
    $query = mysqli_query($idConexion,$comando);
    //Verificar si existe el usuario
    $cuantasFilasHay = mysqli_num_rows($query);
    //Devolver true or false
    if($cuantasFilasHay=="0"){
        $estatus = "false";
    }else{
        $estatus = "true";
    }
    //Cerrar Conexion
    desconectar($idConexion);
    return $estatus;
}
