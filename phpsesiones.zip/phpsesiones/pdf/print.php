<?php
require('WriteTag.php');

$pdf=new PDF_WriteTag();
$pdf->SetMargins(30,15,25);
$pdf->SetFont('arial','',12);
$pdf->AddPage();

// Stylesheet
$pdf->SetStyle("p","courier","N",12,"10,100,250",15);
$pdf->SetStyle("h1","times","N",18,"102,0,102",0);
$pdf->SetStyle("a","times","BU",9,"0,0,255");
$pdf->SetStyle("pers","times","I",0,"255,0,0");
$pdf->SetStyle("place","arial","U",0,"153,0,0");
$pdf->SetStyle("vb","times","B",0,"102,153,153");

// Title

$pdf->SetLineWidth(0);
$pdf->SetFillColor(255,255,204);


$pdf->Ln(15);

// Text
$txt=utf8_encode(" 
<p>ES CONFORME A SU <vb>ORIGINAL</vb> con la cual se confrontó y para efectos legales, se extiende la presente en el registro del estado familiar .-la Alcaldía Municipal de Chapeltique,//// ADVERTENCIA: CUALQUIER ALTERACION ANULA LA PRESENTE CERTIFICACION. ////</p>
");

$pdf->SetLineWidth(0.1);
$pdf->SetFillColor(255,255,204);
//$pdf->SetDrawColor(102,0,102);
$pdf->WriteTag(0,7,utf8_decode($txt),1,"J",0,7);

$pdf->Ln(5);




$pdf->Output();
?>