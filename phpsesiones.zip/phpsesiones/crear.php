<?php
    session_start();
    require("conexion.php");
    if(!isset($_SESSION["usuario_logeado"])){
        echo "<script>location.replace('login.php');</script>";
    }
?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Formulario para Membresias</title>
</head>

<body>
    <form method="post" action="crear.php">
        <label>
            CODIGO DE MEMBRESIA:
            <br>
            <input type="text" name="codigo">
        </label><br>
        <label>
            PROPIETARIO:
            <br>
            <input type="text" name="propietario">
        </label><br>
        <label>
            FECHA:
            <br>
            <input type="date" name="fecha">
        </label><br>
        <input type="submit" value="Guardar Datos">
        <a href="index.php">REGRESAR</a>
    </form>

    <?php
    if ($_POST) {
        $codigo = $_POST["codigo"];
        $propietario = $_POST["propietario"];
        $fecha = $_POST["fecha"];

        //Conectate
        $idConexion = conectar();
        //Prepara el comando
        $comando = "INSERT INTO membresias (codigo,nombre,fecha) VALUES('$codigo','$propietario','$fecha')";
        //Ejecutalo
        if (mysqli_query($idConexion, $comando)) {
            echo "<script>alert('Datos guardados con exito');
            location.replace('index.php');</script>";
        } else {
            echo "<script>alert('Error al intentar guardar la membresia');</script>";
        }
        //Cerra Conexion
        desconectar($idConexion);
    }
    ?>
</body>

</html>