<?php
    session_start();
    require("conexion.php");
    if(!isset($_SESSION["usuario_logeado"])){
        echo "<script>location.replace('login.php');</script>";
    }

//Verifica si existe la variable id_membresia
if (isset($_GET["id_membresia"])) {
    //Si existe y si está vacía entonces intenta eliminar
    if ($_GET["id_membresia"] != "") {
        //Conectarme
        $idConexion = conectar();
        //Preparar un comando DELETE
        $comando = "DELETE FROM membresias WHERE id_mebresia='$_GET[id_membresia]'";
        //Ejecutar el comando
        if (mysqli_query($idConexion, $comando)) {
            echo "<script>alert('Datos eliminados con exito');</script>";
        } else {
            echo "<script>alert('Error al intentar eliminar la membresia');</script>";
        }
        //desconectarme
        desconectar($idConexion);
        //redireccionar a la pagina principal
        echo "<script>location.replace('index.php');</script>";
    }
}
