<?php
    session_start();
    require("conexion.php");
    if(!isset($_SESSION["usuario_logeado"])){
        echo "<script>location.replace('login.php');</script>";
    }


//Si existe el id_membresia
if (isset($_GET["id_membresia"])) {
    $id_membresia = $_GET["id_membresia"];

    //Conectate
    $idConexion = conectar();
    //prepara comando
    $comando = "select * from membresias WHERE id_mebresia='$id_membresia'";
    //ejecutalo
    $query = mysqli_query($idConexion, $comando);
    //Extrae la informacion
    $extraer = mysqli_fetch_array($query);
    $codigo = $extraer["codigo"];
    $propietario = $extraer["nombre"];
    $fecha = $extraer["fecha"];
    //desconectas
    desconectar($idConexion);
} else {
    $id_membresia = "";
}
?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Formulario para Membresias</title>
</head>

<body>
    <form method="post" action="editar.php">
        <input type="hidden" name="id_membresia" value="<?php echo $id_membresia; ?>">
        <label>
            CODIGO DE MEMBRESIA:
            <br>
            <input type="text" name="codigo" value="<?php echo $codigo; ?>">
        </label><br>
        <label>
            PROPIETARIO:
            <br>
            <input type="text" name="propietario" value="<?php echo $propietario; ?>">
        </label><br>
        <label>
            FECHA:
            <br>
            <input type="date" name="fecha" value="<?php echo $fecha; ?>">
        </label><br>
        <input type="submit" value="Guardar Datos">
        <a href="index.php">REGRESAR</a>
    </form>

    <?php
    if ($_POST) {
        $id_membresia = $_POST["id_membresia"];
        $codigo = $_POST["codigo"];
        $propietario = $_POST["propietario"];
        $fecha = $_POST["fecha"];

        //Conectate
        $idConexion = conectar();
        //Prepara el comando
        $comando = "UPDATE membresias SET codigo='$codigo',nombre='$propietario',fecha='$fecha' WHERE id_mebresia='$id_membresia'";
        //Ejecutalo
        if (mysqli_query($idConexion, $comando)) {
            echo "<script>alert('Datos actualizados con exito');
            location.replace('index.php');</script>";
        } else {
            echo "<script>alert('Error al intentar actualizar la membresia');</script>";
        }
        //Cerra Conexion
        desconectar($idConexion);
    }
    ?>
</body>

</html>