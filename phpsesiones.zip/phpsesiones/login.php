<?php 
    session_start();
    require("conexion.php");
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Inicio de Sesion</title>
</head>
<body>
    <form method="post" action="login.php">

    Usuario: <br>
    <input type="text" name="usuario" id="usuario"><br>
    Password: <br>
    <input type="password" name="password" id="password"><br>
    <input type="submit" value="Iniciar Sesion">
    </form>

    <?php
        if($_POST){
            $usuario = $_POST["usuario"];
            $password = $_POST["password"];

            $estatusDelUsuario = iniciarSesion($usuario,$password);

            if($estatusDelUsuario=="true"){
                //Si es la correcta, crea la sesión
                //setcookie("usuario_logeado",$usuario);
                $_SESSION["usuario_logeado"] = $usuario;
                //setcookie("password",md5($password));
                $_SESSION["password"] =md5($password);
                //Una vez crees la sesión, redireccionalo a la pagina principal
                echo "
                <script>alert('Bienvenido $usuario :-)');
                location.replace('index.php');</script>
                ";
            }else{
                echo "
                <script>alert('El usuario o password es incorrecto');
                </script>
                ";
            }
            
        }
    ?>
</body>
</html>