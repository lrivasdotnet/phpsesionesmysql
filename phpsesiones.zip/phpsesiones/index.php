<?php
    session_start();
    require("conexion.php");
    if(!isset($_SESSION["usuario_logeado"])){
        echo "<script>location.replace('login.php');</script>";
    }
?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Lista Membresia</title>
</head>

<body>
    <h1>LISTA DE MEMBRESIAS</h1>
    <br>
    <a href="crear.php">CREAR MEMBRESIA</a>
    <a href="salir.php">CERRAR SESION</a>
    <a href="imprimir_reporte.php" target="_blank">IMPRIMIR PDF</a>

    <br><br>
    <table style="width:800px;border:solid 1px black;">
        <tr>
            <td>ID</td>
            <td>Propietario</td>
            <td>Codigo</td>
            <td>Fecha</td>
            <td>Acciones</td>
        </tr>

        <?php
        //Conectes
        $idConexion = conectar();
        //Prepares una consulta
        $consulta = "select * from membresias order by fecha DESC";
        //Ejecutes una consulta
        $query = mysqli_query($idConexion, $consulta);
        //Verifiques si hay datos
        $verificaFilas = mysqli_num_rows($query);
        //Si hay datos, recorre todos los datos y mostralo en el navegador
        if ($verificaFilas == 0) {
            echo "
            <tr>
                <td colspan=\"5\">No existen datos</td>
            </tr>
            ";
        } else {
            //Recorrer
            while ($cadaFila = mysqli_fetch_array($query)) {
                echo "
                <tr>
                    <td>$cadaFila[id_mebresia]</td>
                    <td>$cadaFila[nombre]</td>
                    <td>$cadaFila[codigo]</td>
                    <td>$cadaFila[fecha]</td>
                    <td>
                        <a href='editar.php?id_membresia=$cadaFila[id_mebresia]'>Editar</a>
                        <a href='eliminar.php?id_membresia=$cadaFila[id_mebresia]'>Eliminar</a>
                    </td>
                </tr>
                ";
            }
        }
        //Cerrar la conexión
        desconectar($idConexion);
        ?>

    </table>
</body>

</html>